# Mini MMORPG Mobile V3
Joystick com isolamento de toque, corrida, mapa maior, múltiplos inimigos, drops, XP/moedas, inventário, equipamentos e minijogo de pesca original.
Abra `.github/workflows/build-apk.yml` pelo GitHub Actions para gerar o APK.
