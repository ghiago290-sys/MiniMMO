# Mini MMORPG Mobile — Android V2

Projeto Android pronto para abrir no Android Studio.

## O que já existe
- jogo 3D em terceira pessoa
- personagem 3D simples
- câmera seguindo o personagem
- joystick touch
- mapa com vila e floresta
- lobo como primeiro inimigo
- seleção de alvo
- ataque
- vida, XP e níveis
- tela cheia em paisagem

## Como gerar o APK
1. Instale o Android Studio.
2. Abra esta pasta como projeto.
3. Aguarde o Gradle sincronizar.
4. Use **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de debug será criado em `app/build/outputs/apk/debug/`.

## Observação
O jogo usa Three.js por CDN, então a primeira execução precisa de internet para carregar o motor 3D.
A estrutura Android já está preparada para depois colocar os arquivos do motor 3D localmente e deixar o jogo totalmente offline.
