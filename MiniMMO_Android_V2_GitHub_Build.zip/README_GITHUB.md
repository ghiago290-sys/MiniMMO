# Mini MMORPG Mobile V2 — Build pelo celular

Este projeto já contém um workflow do GitHub Actions para compilar o APK na nuvem.

## No celular

1. Crie um repositório no GitHub.
2. Envie todos os arquivos desta pasta para o repositório, mantendo as pastas.
3. Abra a aba **Actions**.
4. Selecione **Build Mini MMORPG APK**.
5. Toque em **Run workflow**.
6. Quando terminar, abra a execução concluída.
7. Na área **Artifacts**, baixe **MiniMMO-V2-APK**.
8. Dentro do ZIP estará o `app-debug.apk`.

O GitHub Actions executa workflows em runners hospedados; o workflow usa Gradle para montar o APK e salva o APK como artifact.
